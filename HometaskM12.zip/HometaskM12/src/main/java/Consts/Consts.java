package Consts;

public class Consts {
    public static final String HOME_PAGE_URL = "https://kidkiddos.com/";
    public static final String LOGIN_PAGE_URL = "https://kidkiddos.com/account/login";
    public static final String BOOKS_RESULTS_PAGE_ENGLISH_URL = "https://kidkiddos.com/collections/english-only";
    public static final String PRODUCT_PAGE_URL = "https://kidkiddos.com/collections/english-only/products/i-love-to-brush-my-teeth-childrens-book-english-only";
    public static final String CART_PAGE_URL = "https://kidkiddos.com/cart";


}
